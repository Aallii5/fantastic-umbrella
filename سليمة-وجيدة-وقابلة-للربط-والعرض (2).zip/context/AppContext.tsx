import React, { createContext, useContext, useReducer, useEffect, ReactNode, useMemo } from 'react';
import { AppState, User, UserStatus, College, Specialization, Level, Subject, ContentFile, ContentType, Notification, BeforeInstallPromptEvent } from '../types';
import { INITIAL_STATE } from '../constants';
import { Action } from './actions';

// Define a simplified type for the actions object for context typing
type AppActions = {
    [key: string]: (...args: any[]) => Promise<void>;
};

const AppContext = createContext<{
  state: AppState;
  actions: AppActions;
}>({
    state: INITIAL_STATE,
    actions: {},
});

// Helper function to generate unique IDs
const generateId = () => `id_${new Date().getTime()}_${Math.random().toString(36).substr(2, 9)}`;

const appReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'INITIALIZE_STATE':
        return { ...action.payload, isInitialized: true };
    case 'SET_LOADING':
        return { ...state, isLoading: action.payload };
    case 'LOGIN':
      return { ...state, currentUser: action.payload.user };
    case 'LOGOUT':
      return { ...state, currentUser: null, originalUser: null };
    case 'REGISTER':
      return { ...state, users: [...state.users, action.payload.user] };
    case 'UPDATE_USER_STATUS':
        return {
            ...state,
            users: state.users.map(user =>
                user.id === action.payload.userId
                    ? { ...user, status: action.payload.status }
                    : user
            )
        };
    case 'ASSIGN_SUBJECT_TO_ASSISTANT':
        return {
            ...state,
            users: state.users.map(user =>
                user.id === action.payload.userId
                    ? { ...user, assignedSubjectId: action.payload.subjectId }
                    : user
            )
        };
    case 'SWITCH_TO_USER':
        return {
            ...state,
            originalUser: state.currentUser,
            currentUser: action.payload.user,
        };
    case 'SWITCH_BACK_TO_ADMIN':
        return {
            ...state,
            currentUser: state.originalUser,
            originalUser: null,
        };
    
    // --- Content Management Reducers ---
    case 'ADD_COLLEGE': {
        const newCollege: College = { id: generateId(), name: action.payload.name, specializations: [], levels: [] };
        return { ...state, colleges: [...state.colleges, newCollege] };
    }
    case 'DELETE_COLLEGE': {
        return { ...state, colleges: state.colleges.filter(c => c.id !== action.payload.collegeId) };
    }

    case 'ADD_SPECIALIZATION': {
        const newSpecialization: Specialization = { id: generateId(), name: action.payload.name, levels: [] };
        return { ...state, colleges: state.colleges.map(c => c.id === action.payload.collegeId ? { ...c, specializations: [...c.specializations, newSpecialization] } : c) };
    }
    case 'DELETE_SPECIALIZATION': {
        return { ...state, colleges: state.colleges.map(c => c.id === action.payload.collegeId ? { ...c, specializations: c.specializations.filter(s => s.id !== action.payload.specializationId) } : c) };
    }

    case 'ADD_LEVEL': {
        const newLevel: Level = { id: generateId(), name: action.payload.name, subjects: [] };
        return {
            ...state,
            colleges: state.colleges.map(c => {
                if (c.id !== action.payload.collegeId) return c;
                if (action.payload.specializationId) {
                    return { ...c, specializations: c.specializations.map(s => s.id === action.payload.specializationId ? { ...s, levels: [...s.levels, newLevel] } : s) };
                } else {
                    return { ...c, levels: [...c.levels, newLevel] };
                }
            }),
        };
    }
     case 'DELETE_LEVEL': {
        return {
            ...state,
            colleges: state.colleges.map(c => {
                if (c.id !== action.payload.collegeId) return c;
                if (action.payload.specializationId) {
                    return { ...c, specializations: c.specializations.map(s => s.id === action.payload.specializationId ? { ...s, levels: s.levels.filter(l => l.id !== action.payload.levelId) } : s) };
                } else {
                    return { ...c, levels: c.levels.filter(l => l.id !== action.payload.levelId) };
                }
            }),
        };
    }
    
    case 'ADD_SUBJECT': {
        const { collegeId, specializationId, levelId, name } = action.payload;
        const newSubject: Subject = { id: generateId(), name, content: { [ContentType.CURRICULUM]: [], [ContentType.LECTURES]: [], [ContentType.SUMMARIES]: [], [ContentType.EXAMS]: [] } };
        return {
            ...state,
            colleges: state.colleges.map(college => {
                if (college.id !== collegeId) return college;
                const updateLevels = (levels: Level[]) => levels.map(level => level.id !== levelId ? level : { ...level, subjects: [...level.subjects, newSubject] });
                if (specializationId) {
                    return { ...college, specializations: college.specializations.map(spec => spec.id !== specializationId ? spec : { ...spec, levels: updateLevels(spec.levels) }) };
                } else {
                    return { ...college, levels: updateLevels(college.levels) };
                }
            }),
        };
    }

    case 'DELETE_SUBJECT': {
        const { collegeId, specializationId, levelId, subjectId } = action.payload;
        return {
            ...state,
            colleges: state.colleges.map(college => {
                if (college.id !== collegeId) return college;
                const updateLevels = (levels: Level[]) => levels.map(level => level.id !== levelId ? level : { ...level, subjects: level.subjects.filter(subject => subject.id !== subjectId) });
                if (specializationId) {
                    return { ...college, specializations: college.specializations.map(spec => spec.id !== specializationId ? spec : { ...spec, levels: updateLevels(spec.levels) }) };
                } else {
                    return { ...college, levels: updateLevels(college.levels) };
                }
            })
        };
    }

    case 'ADD_CONTENT_FILE': {
        const { collegeId, specializationId, levelId, subjectId, contentType, file } = action.payload;
        const newFile = { ...file, id: generateId() };
        return {
            ...state,
            colleges: state.colleges.map(college => {
                if (college.id !== collegeId) return college;
                const updateSubjects = (subjects: Subject[]) => subjects.map(subject => subject.id !== subjectId ? subject : { ...subject, content: { ...subject.content, [contentType]: [...subject.content[contentType], newFile] } });
                const updateLevels = (levels: Level[]) => levels.map(level => level.id !== levelId ? level : { ...level, subjects: updateSubjects(level.subjects) });
                if (specializationId) {
                    return { ...college, specializations: college.specializations.map(spec => spec.id !== specializationId ? spec : { ...spec, levels: updateLevels(spec.levels) }) };
                } else {
                    return { ...college, levels: updateLevels(college.levels) };
                }
            }),
        };
    }
    
     case 'DELETE_CONTENT_FILE': {
        const { collegeId, specializationId, levelId, subjectId, contentType, fileId } = action.payload;
        return {
            ...state,
            colleges: state.colleges.map(college => {
                if (college.id !== collegeId) return college;
                const updateSubjects = (subjects: Subject[]) => subjects.map(subject => subject.id !== subjectId ? subject : { ...subject, content: { ...subject.content, [contentType]: subject.content[contentType].filter(f => f.id !== fileId) } });
                const updateLevels = (levels: Level[]) => levels.map(level => level.id !== levelId ? level : { ...level, subjects: updateSubjects(level.subjects) });
                if (specializationId) {
                    return { ...college, specializations: college.specializations.map(spec => spec.id !== specializationId ? spec : { ...spec, levels: updateLevels(spec.levels) }) };
                } else {
                    return { ...college, levels: updateLevels(college.levels) };
                }
            }),
        };
    }

    case 'ADD_NOTIFICATION': {
        const newNotification: Notification = { id: generateId(), message: action.payload.message, target: action.payload.target, timestamp: new Date(), readBy: [] };
        return { ...state, notifications: [newNotification, ...state.notifications] };
    }
    
    case 'MARK_NOTIFICATION_AS_READ': {
        return { ...state, notifications: state.notifications.map(n => n.id === action.payload.notificationId ? { ...n, readBy: [...new Set([...n.readBy, action.payload.userId])] } : n ) };
    }
    
    case 'SET_INSTALL_PROMPT': {
        return { ...state, installPromptEvent: action.payload.event, showInstallButton: !!action.payload.event };
    }

    default:
      return state;
  }
};

const APP_STATE_STORAGE_KEY = 'huscState';
const FAKE_API_DELAY = 500; // milliseconds

export const AppContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, INITIAL_STATE);

  useEffect(() => {
    const initializeApp = async () => {
        await new Promise(res => setTimeout(res, 1000)); // Simulate initial fetch
        try {
            const storedState = localStorage.getItem(APP_STATE_STORAGE_KEY);
            if (storedState) {
                const parsedState = JSON.parse(storedState);
                parsedState.notifications = parsedState.notifications.map((n: any) => ({ ...n, timestamp: new Date(n.timestamp) }));
                dispatch({ type: 'INITIALIZE_STATE', payload: { ...parsedState, isLoading: false, isInitialized: true, currentUser: null } }); // Reset user on load
            } else {
                 dispatch({ type: 'INITIALIZE_STATE', payload: { ...INITIAL_STATE, isInitialized: true }});
            }
        } catch (error) {
            console.error("Could not parse stored state:", error);
            dispatch({ type: 'INITIALIZE_STATE', payload: { ...INITIAL_STATE, isInitialized: true }});
        }
    };
    initializeApp();
  }, []);
  
  // PWA Install Prompt Handler
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        dispatch({ type: 'SET_INSTALL_PROMPT', payload: { event: e as BeforeInstallPromptEvent } });
    };

    const handleAppInstalled = () => {
        dispatch({ type: 'SET_INSTALL_PROMPT', payload: { event: null } });
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  useEffect(() => {
    // Save state to localStorage whenever it changes, except for transient state
    if (state.isInitialized) {
        try {
            const stateToSave = { ...state, isLoading: false, currentUser: null, originalUser: null, installPromptEvent: null, showInstallButton: false };
            localStorage.setItem(APP_STATE_STORAGE_KEY, JSON.stringify(stateToSave));
        } catch (error) {
            console.error("Could not save state to localStorage:", error);
        }
    }
  }, [state]);

  const actions = useMemo(() => {
    const withLoading = async (action: Action) => {
        dispatch({ type: 'SET_LOADING', payload: true });
        await new Promise(res => setTimeout(res, FAKE_API_DELAY));
        dispatch(action);
        dispatch({ type: 'SET_LOADING', payload: false });
    };

    return {
        login: async (user: User) => withLoading({ type: 'LOGIN', payload: { user } }),
        logout: async () => withLoading({ type: 'LOGOUT' }),
        register: async (user: User) => withLoading({ type: 'REGISTER', payload: { user } }),
        updateUserStatus: async (userId: string, status: UserStatus) => withLoading({ type: 'UPDATE_USER_STATUS', payload: { userId, status } }),
        assignSubjectToAssistant: async (userId: string, subjectId: string) => withLoading({ type: 'ASSIGN_SUBJECT_TO_ASSISTANT', payload: { userId, subjectId } }),
        switchToUser: async (user: User) => withLoading({ type: 'SWITCH_TO_USER', payload: { user } }),
        switchBackToAdmin: async () => withLoading({ type: 'SWITCH_BACK_TO_ADMIN' }),
        addCollege: async (name: string) => withLoading({ type: 'ADD_COLLEGE', payload: { name } }),
        deleteCollege: async (collegeId: string) => withLoading({ type: 'DELETE_COLLEGE', payload: { collegeId } }),
        addSpecialization: async (collegeId: string, name: string) => withLoading({ type: 'ADD_SPECIALIZATION', payload: { collegeId, name } }),
        deleteSpecialization: async (collegeId: string, specializationId: string) => withLoading({ type: 'DELETE_SPECIALIZATION', payload: { collegeId, specializationId } }),
        addLevel: async (collegeId: string, name: string, specializationId?: string) => withLoading({ type: 'ADD_LEVEL', payload: { collegeId, specializationId, name } }),
        deleteLevel: async (payload: { collegeId: string; specializationId?: string; levelId: string }) => withLoading({ type: 'DELETE_LEVEL', payload }),
        addSubject: async (payload: { collegeId: string; specializationId?: string; levelId: string; name: string }) => withLoading({ type: 'ADD_SUBJECT', payload }),
        deleteSubject: async (payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string }) => withLoading({ type: 'DELETE_SUBJECT', payload }),
        addContentFile: async (payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string; contentType: ContentType; file: Omit<ContentFile, 'id'> }) => withLoading({ type: 'ADD_CONTENT_FILE', payload }),
        deleteContentFile: async (payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string; contentType: ContentType; fileId: string }) => withLoading({ type: 'DELETE_CONTENT_FILE', payload }),
        addNotification: async (payload: { message: string; target: 'all' | { collegeId: string } }) => withLoading({ type: 'ADD_NOTIFICATION', payload }),
        markNotificationAsRead: async (notificationId: string, userId: string) => withLoading({ type: 'MARK_NOTIFICATION_AS_READ', payload: { notificationId, userId } }),
        triggerInstallPrompt: async () => {
            const { installPromptEvent } = state;
            if (!installPromptEvent) {
                return;
            }
            installPromptEvent.prompt();
            await installPromptEvent.userChoice;
            dispatch({ type: 'SET_INSTALL_PROMPT', payload: { event: null } });
        },
    };
  }, [state.installPromptEvent]);

  return (
    <AppContext.Provider value={{ state, actions }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppContextProvider');
  }
  return context;
};