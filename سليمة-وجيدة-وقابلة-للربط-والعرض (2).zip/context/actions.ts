import { User, UserStatus, ContentFile, ContentType, AppState, BeforeInstallPromptEvent } from '../types';

export type Action =
  | { type: 'LOGIN'; payload: { user: User } }
  | { type: 'LOGOUT' }
  | { type: 'REGISTER'; payload: { user: User } }
  | { type: 'UPDATE_USER_STATUS'; payload: { userId: string; status: User['status'] } }
  | { type: 'ASSIGN_SUBJECT_TO_ASSISTANT', payload: { userId: string, subjectId: string } }
  | { type: 'SWITCH_TO_USER'; payload: { user: User } }
  | { type: 'SWITCH_BACK_TO_ADMIN' }
  | { type: 'ADD_COLLEGE'; payload: { name: string } }
  | { type: 'DELETE_COLLEGE'; payload: { collegeId: string } }
  | { type: 'ADD_SPECIALIZATION'; payload: { collegeId: string; name: string } }
  | { type: 'DELETE_SPECIALIZATION'; payload: { collegeId: string; specializationId: string } }
  | { type: 'ADD_LEVEL'; payload: { collegeId: string; specializationId?: string; name: string } }
  | { type: 'DELETE_LEVEL'; payload: { collegeId: string; specializationId?: string; levelId: string } }
  | { type: 'ADD_SUBJECT'; payload: { collegeId: string; specializationId?: string; levelId: string; name: string } }
  | { type: 'DELETE_SUBJECT'; payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string } }
  | { type: 'ADD_CONTENT_FILE'; payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string; contentType: ContentType; file: Omit<ContentFile, 'id'> } }
  | { type: 'DELETE_CONTENT_FILE'; payload: { collegeId: string; specializationId?: string; levelId: string; subjectId: string; contentType: ContentType; fileId: string } }
  | { type: 'ADD_NOTIFICATION'; payload: { message: string; target: 'all' | { collegeId: string } } }
  | { type: 'MARK_NOTIFICATION_AS_READ'; payload: { notificationId: string, userId: string } }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'INITIALIZE_STATE'; payload: AppState }
  | { type: 'SET_INSTALL_PROMPT'; payload: { event: BeforeInstallPromptEvent | null } };