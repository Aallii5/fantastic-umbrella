import React from 'react';
import { AppContextProvider, useAppContext } from './context/AppContext';
import AuthScreen from './screens/AuthScreen';
import Dashboard from './screens/Dashboard';
import './context/actions'; // Ensure types are bundled

const App: React.FC = () => {
  return (
    <AppContextProvider>
      <AppContent />
    </AppContextProvider>
  );
};

const SplashScreen: React.FC = () => (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 text-white">
        <h1 className="text-4xl font-bold text-cyan-400 mb-4">مركز جامعة الحديدة العلمي</h1>
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-cyan-400"></div>
        <p className="mt-4 text-gray-400">جاري تحميل البيانات...</p>
    </div>
);


const AppContent: React.FC = () => {
  const { state } = useAppContext();
  
  if (!state.isInitialized) {
      return <SplashScreen />;
  }

  return (
    <div>
      {state.currentUser ? <Dashboard /> : <AuthScreen />}
    </div>
  );
};

export default App;