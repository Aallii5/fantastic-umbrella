import { AppState, Role, UserStatus, College, ContentType } from './types';

export const PRIMARY_ADMIN_ID = '772757344';
export const PRIMARY_ADMIN_PASS = '344';

export const INITIAL_STATE: AppState = {
  currentUser: null,
  colleges: [
    {
      id: 'c1',
      name: 'كلية الهندسة',
      specializations: [
        {
          id: 's1-1',
          name: 'هندسة مدنية',
          levels: [
            {
              id: 'l1-1-1',
              name: 'المستوى الأول',
              subjects: [
                { id: 'sub1', name: 'الرياضيات 1', content: { [ContentType.CURRICULUM]: [], [ContentType.LECTURES]: [], [ContentType.SUMMARIES]: [], [ContentType.EXAMS]: [] } },
                { id: 'sub2', name: 'الفيزياء 1', content: { [ContentType.CURRICULUM]: [], [ContentType.LECTURES]: [], [ContentType.SUMMARIES]: [], [ContentType.EXAMS]: [] } },
              ],
            },
            { id: 'l1-1-2', name: 'المستوى الثاني', subjects: [] },
          ],
        },
        {
          id: 's1-2',
          name: 'هندسة معمارية',
          levels: [{ id: 'l1-2-1', name: 'المستوى الأول', subjects: [] }],
        },
      ],
      levels: [],
    },
    {
      id: 'c2',
      name: 'كلية الآداب',
      specializations: [],
      levels: [
        {
          id: 'l2-1',
          name: 'المستوى الأول',
          subjects: [
              { id: 'sub3', name: 'تاريخ قديم', content: { [ContentType.CURRICULUM]: [{id: 'f1', name: 'منهج التاريخ.pdf', type: 'PDF', url: '#'}], [ContentType.LECTURES]: [], [ContentType.SUMMARIES]: [], [ContentType.EXAMS]: [] } },
          ],
        },
        { id: 'l2-2', name: 'المستوى الثاني', subjects: [] },
      ],
    },
  ],
  users: [
    {
      id: PRIMARY_ADMIN_ID,
      fullName: 'المدير الأساسي',
      password: PRIMARY_ADMIN_PASS,
      collegeId: '',
      levelId: '',
      phone: '000000000',
      role: Role.PRIMARY_ADMIN,
      status: UserStatus.APPROVED,
    },
    {
      id: '12345',
      fullName: 'طالب معتمد',
      password: '1234',
      collegeId: 'c1',
      specializationId: 's1-1',
      levelId: 'l1-1-1',
      phone: '111222333',
      role: Role.STUDENT,
      status: UserStatus.APPROVED,
    },
    {
      id: '54321',
      fullName: 'طالب قيد الانتظار',
      password: '4321',
      collegeId: 'c2',
      levelId: 'l2-1',
      phone: '444555666',
      role: Role.STUDENT,
      status: UserStatus.PENDING,
    },
    {
      id: '67890',
      fullName: 'مشرف كلية الهندسة',
      password: '6789',
      collegeId: 'c1',
      levelId: 'l1-1-1',
      phone: '777888999',
      role: Role.SUPERVISOR,
      status: UserStatus.APPROVED,
    },
    {
      id: '11223',
      fullName: 'مساعد مادة الرياضيات 1',
      password: '1122',
      collegeId: 'c1',
      specializationId: 's1-1',
      levelId: 'l1-1-1',
      assignedSubjectId: 'sub1',
      phone: '101010101',
      role: Role.ASSISTANT,
      status: UserStatus.APPROVED,
    },
  ],
  notifications: [
      { id: 'n1', message: 'مرحباً بكم في منصة مركز جامعة الحديدة العلمي!', timestamp: new Date(), target: 'all', readBy: [] }
  ],
  downloads: {},
  originalUser: null,
  isLoading: false,
  isInitialized: false,
  installPromptEvent: null,
  showInstallButton: false,
};