const CACHE_NAME = 'husc-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  // The service worker will dynamically cache other assets upon first visit.
];

// Install event: cache the app shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching app shell');
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .catch(error => {
          console.error('Failed to cache app shell:', error);
      })
  );
});

// Activate event: clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Service Worker: Clearing old cache');
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event: serve from cache, fall back to network, and cache new requests
self.addEventListener('fetch', (event) => {
  // We only want to handle GET requests
  if (event.request.method !== 'GET') {
      return;
  }
  
  event.respondWith(
    caches.open(CACHE_NAME).then((cache) => {
      // Try to find the response in the cache.
      return cache.match(event.request).then((cachedResponse) => {
        // Fetch the resource from the network.
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          // If the network request is successful, cache it.
          if (networkResponse && networkResponse.status === 200 && !event.request.url.startsWith('chrome-extension://')) {
              cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        });

        // Return the cached response if it exists, otherwise, wait for the network response.
        return cachedResponse || fetchPromise;
      });
    })
  );
});
