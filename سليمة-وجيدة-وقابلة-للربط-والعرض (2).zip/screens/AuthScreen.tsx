
import React, { useState, FormEvent } from 'react';
import { useAppContext } from '../context/AppContext';
import { CollegeIcon, LevelIcon, LockIcon, PhoneIcon, UserIcon } from '../components/Icons';
import { Role, User, UserStatus } from '../types';
import { PRIMARY_ADMIN_ID, PRIMARY_ADMIN_PASS } from '../constants';

const AuthScreen: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-md bg-gray-800 rounded-lg shadow-xl p-8">
        <h1 className="text-3xl font-bold text-center text-cyan-400 mb-8">
          {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
        </h1>
        {isLogin ? <LoginForm /> : <RegisterForm />}
        <div className="mt-6 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            {isLogin ? 'ليس لديك حساب؟ إنشاء حساب جديد' : 'لديك حساب بالفعل؟ تسجيل الدخول'}
          </button>
        </div>
      </div>
    </div>
  );
};

const LoginForm: React.FC = () => {
  const { state, actions } = useAppContext();
  const [universityId, setUniversityId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (universityId === PRIMARY_ADMIN_ID && password === PRIMARY_ADMIN_PASS) {
        const adminUser = state.users.find(u => u.id === PRIMARY_ADMIN_ID);
        if (adminUser) {
            await actions.login(adminUser);
            return;
        }
    }

    const user = state.users.find(u => u.id === universityId && u.password === password);
    if (!user) {
      setError('رقم القيد الجامعي أو كلمة المرور غير صحيحة.');
      return;
    }
    if (user.status === UserStatus.PENDING) {
      setError('حسابك قيد المراجعة من قبل الإدارة.');
      return;
    }
    if (user.status !== UserStatus.APPROVED) {
      setError('تم رفض أو حظر حسابك.');
      return;
    }
    await actions.login(user);
  };

  return (
    <form onSubmit={handleLogin} className="space-y-6">
      <div>
        <label className="text-sm font-medium text-gray-300">رقم القيد الجامعي</label>
        <div className="relative mt-1">
          <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><UserIcon /></span>
          <input
            type="text"
            value={universityId}
            onChange={(e) => setUniversityId(e.target.value)}
            className="w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 pr-10 pl-3 py-2"
            required
            disabled={state.isLoading}
          />
        </div>
      </div>
      <div>
        <label className="text-sm font-medium text-gray-300">كلمة المرور</label>
        <div className="relative mt-1">
           <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><LockIcon /></span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 pr-10 pl-3 py-2"
            required
            disabled={state.isLoading}
          />
        </div>
      </div>
      {error && <p className="text-red-400 text-sm">{error}</p>}
      <button type="submit" disabled={state.isLoading} className="w-full bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-500 text-white font-bold py-2 px-4 rounded-md transition-colors">
        {state.isLoading ? 'جاري التحقق...' : 'تسجيل الدخول'}
      </button>
    </form>
  );
};

const RegisterForm: React.FC = () => {
    const { state, actions } = useAppContext();
    const [formData, setFormData] = useState({
        fullName: '', collegeId: '', specializationId: '', levelId: '', phone: '', universityId: '', password: ''
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    
    const selectedCollege = state.colleges.find(c => c.id === formData.collegeId);
    
    const handleRegister = async (e: FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (formData.password.length !== 4 || !/^\d+$/.test(formData.password)) {
            setError('يجب أن تتكون كلمة المرور من 4 أرقام بالضبط.');
            return;
        }

        if(state.users.some(u => u.id === formData.universityId)) {
            setError('رقم القيد الجامعي هذا مسجل بالفعل.');
            return;
        }

        const newUser: User = {
            id: formData.universityId,
            fullName: formData.fullName,
            password: formData.password,
            collegeId: formData.collegeId,
            specializationId: formData.specializationId,
            levelId: formData.levelId,
            phone: formData.phone,
            role: Role.STUDENT,
            status: UserStatus.PENDING,
        };
        await actions.register(newUser);
        setSuccess('تم إنشاء حسابك بنجاح! سيتم تفعيله بعد موافقة الإدارة.');
    };

    const inputStyles = "w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 pr-10 pl-3 py-2 disabled:opacity-50";
    const selectStyles = "w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 pr-10 pl-3 py-2 appearance-none disabled:opacity-50";

    return (
        <form onSubmit={handleRegister} className="space-y-4">
            <fieldset disabled={state.isLoading}>
                <div>
                    <label className="text-sm font-medium text-gray-300">الاسم الكامل</label>
                    <div className="relative mt-1">
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><UserIcon /></span>
                        <input name="fullName" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} placeholder="الاسم الكامل" required className={inputStyles} />
                    </div>
                </div>

                <div>
                    <label className="text-sm font-medium text-gray-300">الكلية</label>
                    <div className="relative mt-1">
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><CollegeIcon /></span>
                        <select name="collegeId" value={formData.collegeId} onChange={e => setFormData({...formData, collegeId: e.target.value, specializationId: '', levelId: ''})} required className={selectStyles}>
                            <option value="">اختر الكلية</option>
                            {state.colleges.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>

                {selectedCollege && selectedCollege.specializations.length > 0 && (
                    <div>
                        <label className="text-sm font-medium text-gray-300">التخصص</label>
                        <div className="relative mt-1">
                            <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><CollegeIcon className="w-5 h-5 opacity-50" /></span>
                            <select name="specializationId" value={formData.specializationId} onChange={e => setFormData({...formData, specializationId: e.target.value, levelId: ''})} required className={selectStyles}>
                               <option value="">اختر التخصص</option>
                               {selectedCollege.specializations.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                            </select>
                        </div>
                    </div>
                )}
                
                {formData.collegeId && (
                    <div>
                        <label className="text-sm font-medium text-gray-300">المستوى الدراسي</label>
                        <div className="relative mt-1">
                            <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><LevelIcon /></span>
                            <select name="levelId" value={formData.levelId} onChange={e => setFormData({...formData, levelId: e.target.value})} required className={selectStyles}>
                                <option value="">اختر المستوى الدراسي</option>
                                {(selectedCollege?.specializations.find(s=> s.id === formData.specializationId)?.levels || selectedCollege?.levels || []).map(l => (
                                    <option key={l.id} value={l.id}>{l.name}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                )}

                <div>
                    <label className="text-sm font-medium text-gray-300">رقم هاتف الطالب</label>
                    <div className="relative mt-1">
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><PhoneIcon /></span>
                        <input name="phone" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="رقم هاتف الطالب" required className={inputStyles} />
                    </div>
                </div>
                
                <div>
                    <label className="text-sm font-medium text-gray-300">رقم القيد الجامعي</label>
                    <div className="relative mt-1">
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><UserIcon /></span>
                        <input name="universityId" value={formData.universityId} onChange={e => setFormData({...formData, universityId: e.target.value})} placeholder="رقم القيد الجامعي" required className={inputStyles} />
                    </div>
                </div>

                <div>
                    <label className="text-sm font-medium text-gray-300">كلمة المرور (4 أرقام)</label>
                    <div className="relative mt-1">
                        <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400"><LockIcon /></span>
                        <input name="password" type="password" value={formData.password} maxLength={4} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="كلمة المرور (4 أرقام)" required className={inputStyles} />
                    </div>
                </div>
            </fieldset>
             
            {error && <p className="text-red-400 text-sm">{error}</p>}
            {success && <p className="text-green-400 text-sm">{success}</p>}
            <button type="submit" disabled={!!success || state.isLoading} className="w-full bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-500 text-white font-bold py-2 px-4 rounded-md transition-colors">
                 {state.isLoading ? 'جاري الإنشاء...' : 'إنشاء حساب'}
            </button>
        </form>
    );
};

export default AuthScreen;