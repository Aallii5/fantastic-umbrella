import React, { useState, useMemo, Fragment } from 'react';
import { useAppContext } from '../context/AppContext';
import { Role, User, UserStatus, College, Specialization, Level, Subject, ContentFile, ContentType } from '../types';
import {
    HomeIcon, UsersIcon, BookIcon, BellIcon, LogoutIcon, MegaphoneIcon,
    MenuIcon, CloseIcon, PlusIcon, TrashIcon, ChevronLeftIcon, EyeIcon, PdfIcon, VideoIcon, LinkIcon, ImageIcon, FileIcon, DownloadIcon
} from '../components/Icons';

// --- Helper Functions & Components ---

const getFileIcon = (type: ContentFile['type']) => {
    switch (type) {
        case 'PDF': return <PdfIcon className="w-5 h-5 text-red-400" />;
        case 'VIDEO': return <VideoIcon className="w-5 h-5 text-blue-400" />;
        case 'IMAGE': return <ImageIcon className="w-5 h-5 text-green-400" />;
        case 'LINK': return <LinkIcon className="w-5 h-5 text-yellow-400" />;
        default: return <FileIcon className="w-5 h-5 text-gray-400" />;
    }
};

const getGoogleDriveEmbedUrl = (url: string): string => {
    if (!url.includes('drive.google.com')) {
        return url;
    }
    let fileId = null;
    const matchFileId = url.match(/drive\.google\.com\/file\/d\/([^/]+)/);
    if (matchFileId && matchFileId[1]) {
        fileId = matchFileId[1];
    } else {
        const matchIdParam = url.match(/[?&]id=([^&]+)/);
        if (matchIdParam && matchIdParam[1]) {
            fileId = matchIdParam[1];
        }
    }
    return fileId ? `https://drive.google.com/file/d/${fileId}/preview` : url;
};


const FileViewerModal: React.FC<{ url: string; onClose: () => void }> = ({ url, onClose }) => {
    const embedUrl = getGoogleDriveEmbedUrl(url);
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg w-full h-full max-w-6xl flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-cyan-400">عارض الملفات</h3>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700"><CloseIcon /></button>
                </div>
                <div className="flex-1 p-2">
                    <iframe
                        src={embedUrl}
                        className="w-full h-full border-0 rounded-b-lg"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                        title="File Content Viewer"
                    ></iframe>
                </div>
            </div>
        </div>
    );
};

// --- Page Components ---

const HomePage: React.FC = () => {
    const { state } = useAppContext();
    const { currentUser } = state;
    return (
        <div>
            <h1 className="text-3xl font-bold text-cyan-400 mb-4">أهلاً بك في منصة مركز جامعة الحديدة العلمي</h1>
            <p className="text-lg text-gray-300">مرحباً، {currentUser?.fullName}. يمكنك استخدام القائمة الجانبية للوصول إلى المحتوى الدراسي وإدارة حسابك.</p>
        </div>
    );
};

const StudentDashboard: React.FC<{ setViewingFileUrl: (url: string) => void }> = ({ setViewingFileUrl }) => {
    const { state } = useAppContext();
    const { currentUser, colleges } = state;
    const [expandedSubject, setExpandedSubject] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const studentInfo = useMemo(() => {
        if (!currentUser) return null;
        const college = colleges.find(c => c.id === currentUser.collegeId);
        if (!college) return null;
        let level: Level | undefined;
        let specialization: Specialization | undefined;

        if (currentUser.specializationId && college.specializations.length > 0) {
            specialization = college.specializations.find(s => s.id === currentUser.specializationId);
            level = specialization?.levels.find(l => l.id === currentUser.levelId);
        } else {
            level = college.levels.find(l => l.id === currentUser.levelId);
        }
        return { college, specialization, level, subjects: level?.subjects || [] };
    }, [currentUser, colleges]);

    if (!studentInfo || !studentInfo.level) {
        return <p className="text-yellow-400">لم يتم العثور على بياناتك الدراسية. يرجى مراجعة الإدارة.</p>;
    }

    const filteredSubjects = studentInfo.subjects.filter(subject => 
        subject.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <h1 className="text-2xl font-bold text-cyan-400 mb-2">المحتوى الدراسي</h1>
            <p className="text-gray-400 mb-4">{`${studentInfo.college.name} > ${studentInfo.specialization?.name || ''} ${studentInfo.level.name}`}</p>
            
            <div className="mb-4">
                <input
                    type="search"
                    placeholder="ابحث عن مادة أو ملف..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full max-w-lg bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 px-4 py-2"
                />
            </div>

            <div className="space-y-4">
                {filteredSubjects.map(subject => (
                    <div key={subject.id} className="bg-gray-800 rounded-lg overflow-hidden">
                        <button
                            onClick={() => setExpandedSubject(expandedSubject === subject.id ? null : subject.id)}
                            className="w-full text-right flex justify-between items-center p-4 bg-gray-700 hover:bg-gray-600 transition-colors"
                        >
                            <h2 className="text-xl font-semibold">{subject.name}</h2>
                            <ChevronLeftIcon className={`transition-transform transform ${expandedSubject === subject.id ? '-rotate-90' : 'rotate-0'}`} />
                        </button>
                        {expandedSubject === subject.id && (
                            <div className="p-4 space-y-3">
                                {Object.values(ContentType).map(type => {
                                    const files = subject.content[type];
                                    if (files.length === 0) return null;
                                    return (
                                        <div key={type}>
                                            <h3 className="text-lg font-bold text-cyan-400 mb-2 border-b border-gray-600 pb-1">{type}</h3>
                                            <ul className="space-y-2">
                                                {files.map(file => (
                                                    <li key={file.id}>
                                                        <button onClick={() => setViewingFileUrl(file.url)} className="flex items-center space-x-3 space-x-reverse w-full text-right p-2 rounded-md hover:bg-gray-700/50 transition-colors">
                                                            {getFileIcon(file.type)}
                                                            <span>{file.name}</span>
                                                        </button>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

const ContentManagementScreen: React.FC<{ setViewingFileUrl: (url: string) => void }> = ({ setViewingFileUrl }) => {
    const { state, actions } = useAppContext();
    const { colleges, users, currentUser } = state;
    const [path, setPath] = useState<string[]>([]);
    const [searchTerm, setSearchTerm] = useState('');

    const navContext = useMemo(() => {
        const context: {
            college?: College;
            specialization?: Specialization;
            level?: Level;
            subject?: Subject;
        } = {};

        if (path.length === 0) return context;

        context.college = colleges.find(c => c.id === path[0]);
        if (!context.college) return {};

        const hasSpecs = context.college.specializations.length > 0;
        if (hasSpecs) {
            if (path.length > 1) {
                context.specialization = context.college.specializations.find(s => s.id === path[1]);
            }
            if (path.length > 2 && context.specialization) {
                context.level = context.specialization.levels.find(l => l.id === path[2]);
            }
            if (path.length > 3 && context.level) {
                context.subject = context.level.subjects.find(s => s.id === path[3]);
            }
        } else {
            if (path.length > 1) {
                context.level = context.college.levels.find(l => l.id === path[1]);
            }
            if (path.length > 2 && context.level) {
                context.subject = context.level.subjects.find(s => s.id === path[2]);
            }
        }
        return context;
    }, [path, colleges]);

    const goBack = () => setPath(p => p.slice(0, -1));

    const onAdd = async (type: 'college' | 'specialization' | 'level' | 'subject', name: string) => {
        if (!name.trim()) return;
        const { college, specialization, level } = navContext;

        switch (type) {
            case 'college':
                await actions.addCollege(name);
                break;
            case 'specialization':
                if (college) await actions.addSpecialization(college.id, name);
                break;
            case 'level':
                if (college) await actions.addLevel(college.id, name, specialization?.id);
                break;
            case 'subject':
                if (college && level) await actions.addSubject({ collegeId: college.id, specializationId: specialization?.id, levelId: level.id, name });
                break;
        }
    };
    
    const onDelete = async (type: 'college' | 'specialization' | 'level' | 'subject', id: string) => {
        if (!window.confirm('هل أنت متأكد من رغبتك في الحذف؟ لا يمكن التراجع عن هذا الإجراء.')) return;
        const { college, specialization, level } = navContext;
         switch (type) {
            case 'college':
                await actions.deleteCollege(id);
                break;
            case 'specialization':
                if (college) await actions.deleteSpecialization(college.id, id);
                break;
            case 'level':
                if (college) await actions.deleteLevel({ collegeId: college.id, specializationId: specialization?.id, levelId: id });
                break;
            case 'subject':
                if (college && level) await actions.deleteSubject({ collegeId: college.id, specializationId: specialization?.id, levelId: level.id, subjectId: id });
                break;
        }
    };

    const renderCurrentView = () => {
        const { college, specialization, level, subject } = navContext;
        
        if (subject && level && college) { // Subject View
            const onAddFile = async (contentType: ContentType, file: Omit<ContentFile, 'id'>) => {
                await actions.addContentFile({ collegeId: college.id, specializationId: specialization?.id, levelId: level.id, subjectId: subject.id, contentType, file });
            };
            const onDeleteFile = async (contentType: ContentType, fileId: string) => {
                 if (!window.confirm('هل أنت متأكد من رغبتك في حذف هذا الملف؟')) return;
                await actions.deleteContentFile({ collegeId: college.id, specializationId: specialization?.id, levelId: level.id, subjectId: subject.id, contentType, fileId });
            };
            return <SubjectView subject={subject} onAddFile={onAddFile} onDeleteFile={onDeleteFile} setViewingFileUrl={setViewingFileUrl} />;
        }
        if (level) { // Level View (shows subjects)
            return <ItemsView title={`مواد ${level.name}`} items={level.subjects} onSelect={id => setPath(p => [...p, id])} onAdd={(name) => onAdd('subject', name)} onDelete={id => onDelete('subject', id)} />;
        }
        if (specialization) { // Specialization View (shows levels)
            return <ItemsView title={`مستويات ${specialization.name}`} items={specialization.levels} onSelect={id => setPath(p => [...p, id])} onAdd={(name) => onAdd('level', name)} onDelete={id => onDelete('level', id)} />;
        }
        if (college) { // College View (shows specializations or levels)
            const items = college.specializations.length > 0 ? college.specializations : college.levels;
            const itemType = college.specializations.length > 0 ? 'specialization' : 'level';
            return <ItemsView title={itemType === 'specialization' ? `تخصصات ${college.name}` : `مستويات ${college.name}`} items={items} onSelect={id => setPath(p => [...p, id])} onAdd={(name) => onAdd(itemType, name)} onDelete={id => onDelete(itemType, id)} />;
        }
        
        // Root View (shows colleges)
        const filteredColleges = colleges.filter(c => currentUser?.role === Role.PRIMARY_ADMIN || currentUser?.role === Role.ADMIN || currentUser?.collegeId === c.id);
        return <ItemsView title="الكليات" items={filteredColleges} onSelect={id => setPath(p => [...p, id])} onAdd={(name) => onAdd('college', name)} onDelete={id => onDelete('college', id)} hideAddDelete={currentUser?.role === Role.SUPERVISOR} />;
    };
    
    const breadcrumbs = useMemo(() => {
        if (path.length === 0) return [];
        const crumbs = [{ name: 'الكليات', path: [] }];
        let currentPath: string[] = [];
        
        const college = colleges.find(c => c.id === path[0]);
        if (college) {
            currentPath.push(path[0]);
            crumbs.push({ name: college.name, path: [...currentPath]});
            const hasSpecs = college.specializations.length > 0;

            if (hasSpecs) {
                const spec = college.specializations.find(s => s.id === path[1]);
                if (spec) {
                    currentPath.push(path[1]);
                    crumbs.push({ name: spec.name, path: [...currentPath]});
                    const level = spec.levels.find(l => l.id === path[2]);
                     if (level) {
                        currentPath.push(path[2]);
                        crumbs.push({ name: level.name, path: [...currentPath]});
                        const subject = level.subjects.find(s => s.id === path[3]);
                        if (subject) {
                            currentPath.push(path[3]);
                            crumbs.push({ name: subject.name, path: [...currentPath]});
                        }
                     }
                }
            } else {
                 const level = college.levels.find(l => l.id === path[1]);
                 if (level) {
                    currentPath.push(path[1]);
                    crumbs.push({ name: level.name, path: [...currentPath]});
                     const subject = level.subjects.find(s => s.id === path[2]);
                     if (subject) {
                        currentPath.push(path[2]);
                        crumbs.push({ name: subject.name, path: [...currentPath]});
                     }
                 }
            }
        }
        return crumbs;
    }, [path, colleges]);

    if (currentUser?.role === Role.ASSISTANT) {
        // Assistant view: Directly show their assigned subject
        const assistantSubjectInfo = useMemo(() => {
            for (const college of colleges) {
                for (const spec of college.specializations) {
                    for (const level of spec.levels) {
                        const subject = level.subjects.find(s => s.id === currentUser.assignedSubjectId);
                        if (subject) return { subject, collegeId: college.id, specializationId: spec.id, levelId: level.id };
                    }
                }
                for (const level of college.levels) {
                    const subject = level.subjects.find(s => s.id === currentUser.assignedSubjectId);
                    if (subject) return { subject, collegeId: college.id, specializationId: undefined, levelId: level.id };
                }
            }
            return null;
        }, [colleges, currentUser]);

        if (!assistantSubjectInfo) return <p>لم يتم تعيين مادة لك.</p>;
        
        const {subject, collegeId, specializationId, levelId} = assistantSubjectInfo;

        const onAssistantAddFile = async (contentType: ContentType, file: Omit<ContentFile, 'id'>) => {
            await actions.addContentFile({ collegeId, specializationId, levelId, subjectId: subject.id, contentType, file });
        };
        const onAssistantDeleteFile = async (contentType: ContentType, fileId: string) => {
             if (!window.confirm('هل أنت متأكد من رغبتك في حذف هذا الملف؟')) return;
            await actions.deleteContentFile({ collegeId, specializationId, levelId, subjectId: subject.id, contentType, fileId });
        };

        return <div>
            <h1 className="text-2xl font-bold text-cyan-400 mb-4">إدارة محتوى: {subject.name}</h1>
            <SubjectView subject={subject} onAddFile={onAssistantAddFile} onDeleteFile={onAssistantDeleteFile} setViewingFileUrl={setViewingFileUrl} />
        </div>;
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold text-cyan-400">إدارة المحتوى الدراسي</h1>
                {path.length > 0 && <button onClick={goBack} className="flex items-center space-x-2 space-x-reverse text-gray-300 hover:text-white"><ChevronLeftIcon /> <span>رجوع</span></button>}
            </div>
            <div className="flex items-center space-x-2 space-x-reverse text-sm mb-4 flex-wrap">
                {breadcrumbs.map((crumb, i) => (
                    <Fragment key={i}>
                        <button onClick={() => setPath(crumb.path)} className="hover:underline">{crumb.name}</button>
                        {i < breadcrumbs.length - 1 && <span className="mx-1">/</span>}
                    </Fragment>
                ))}
            </div>
             <div className="mb-4">
                <input
                    type="search"
                    placeholder="ابحث..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full max-w-lg bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 px-4 py-2"
                />
            </div>
            {React.cloneElement(renderCurrentView(), { searchTerm })}
        </div>
    );
};

const ItemsView: React.FC<{title: string, items: {id: string, name: string}[], onSelect: (id: string) => void, onAdd: (name: string) => void, onDelete: (id: string) => void, hideAddDelete?: boolean, searchTerm?: string}> = ({ title, items, onSelect, onAdd, onDelete, hideAddDelete=false, searchTerm='' }) => {
    const [newItemName, setNewItemName] = useState('');
    const [showAddForm, setShowAddForm] = useState(false);

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        onAdd(newItemName);
        setNewItemName('');
        setShowAddForm(false);
    };

    const filteredItems = items.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-cyan-400">{title}</h2>
                {!hideAddDelete && !showAddForm && <button onClick={() => setShowAddForm(true)} className="flex items-center space-x-1 space-x-reverse bg-cyan-600 px-3 py-1 rounded hover:bg-cyan-700"><PlusIcon className="w-4 h-4" /> <span>إضافة جديد</span></button>}
            </div>
            {!hideAddDelete && showAddForm && (
                <form onSubmit={handleAdd} className="bg-gray-700 p-4 rounded-lg mb-4 flex gap-2">
                    <input value={newItemName} onChange={e => setNewItemName(e.target.value)} placeholder={`اسم ${title} الجديد`} className="flex-grow bg-gray-600 rounded px-2 py-1" required/>
                    <button type="submit" className="bg-green-600 px-3 py-1 rounded hover:bg-green-700">حفظ</button>
                    <button type="button" onClick={() => setShowAddForm(false)} className="bg-gray-500 px-3 py-1 rounded hover:bg-gray-600">إلغاء</button>
                </form>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredItems.map(item => (
                    <div key={item.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                        <button onClick={() => onSelect(item.id)} className="text-lg hover:text-cyan-400 flex-grow text-right">{item.name}</button>
                         {!hideAddDelete && <button onClick={() => onDelete(item.id)} className="p-2 text-red-500 hover:text-red-400"><TrashIcon /></button>}
                    </div>
                ))}
            </div>
        </div>
    );
};

const SubjectView: React.FC<{subject: Subject, onAddFile: any, onDeleteFile: any, setViewingFileUrl: (url: string) => void}> = ({ subject, onAddFile, onDeleteFile, setViewingFileUrl }) => {
    const [addingTo, setAddingTo] = useState<ContentType | null>(null);
    const [newFileData, setNewFileData] = useState({ name: '', url: '', type: 'PDF' as ContentFile['type']});
    
    const handleShowAddForm = (type: ContentType) => {
        setAddingTo(type);
        setNewFileData({ name: '', url: '', type: 'PDF' });
    };

    const handleAddFile = (e: React.FormEvent) => {
        e.preventDefault();
        if (!addingTo) return;
        onAddFile(addingTo, newFileData);
        setAddingTo(null);
    };

    return (
        <div className="bg-gray-800 rounded-lg p-4 space-y-4">
            {Object.values(ContentType).map(type => (
                <div key={type}>
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-bold text-cyan-400 border-b border-gray-600 pb-1">{type}</h3>
                        <button onClick={() => handleShowAddForm(type)} className="text-cyan-400 hover:text-cyan-300"><PlusIcon /></button>
                    </div>

                    {addingTo === type && (
                         <form onSubmit={handleAddFile} className="bg-gray-700 p-3 rounded-lg mb-2 space-y-2">
                            <input value={newFileData.name} onChange={e => setNewFileData(d => ({...d, name: e.target.value}))} placeholder="اسم الملف" className="w-full bg-gray-600 rounded px-2 py-1" required />
                            <input value={newFileData.url} onChange={e => setNewFileData(d => ({...d, url: e.target.value}))} placeholder="رابط الملف" className="w-full bg-gray-600 rounded px-2 py-1" required />
                            <select value={newFileData.type} onChange={e => setNewFileData(d => ({...d, type: e.target.value as ContentFile['type']}))} className="w-full bg-gray-600 rounded px-2 py-1">
                                <option value="PDF">PDF</option>
                                <option value="VIDEO">VIDEO</option>
                                <option value="IMAGE">IMAGE</option>
                                <option value="LINK">LINK</option>
                            </select>
                            <div className="flex gap-2">
                                <button type="submit" className="bg-green-600 px-3 py-1 rounded hover:bg-green-700">إضافة</button>
                                <button type="button" onClick={() => setAddingTo(null)} className="bg-gray-500 px-3 py-1 rounded hover:bg-gray-600">إلغاء</button>
                            </div>
                        </form>
                    )}

                    <ul className="space-y-2">
                        {subject.content[type].map(file => (
                            <li key={file.id} className="flex justify-between items-center p-2 rounded-md hover:bg-gray-700/50 group">
                                <button onClick={() => setViewingFileUrl(file.url)} className="flex items-center space-x-3 space-x-reverse flex-grow text-right">
                                    {getFileIcon(file.type)}
                                    <span>{file.name}</span>
                                </button>
                                <button onClick={() => onDeleteFile(type, file.id)} className="p-1 text-red-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon /></button>
                            </li>
                        ))}
                         {subject.content[type].length === 0 && <p className="text-gray-500 text-sm pr-2">لا يوجد ملفات.</p>}
                    </ul>
                </div>
            ))}
        </div>
    );
};

const UserManagement: React.FC = () => {
    const { state, actions } = useAppContext();
    const { users, colleges, currentUser } = state;
    const [filter, setFilter] = useState<UserStatus | 'all'>('all');
    
    const filteredUsers = useMemo(() => {
        return users.filter(user => {
            if (user.role === Role.PRIMARY_ADMIN) return false; // Don't show primary admin
            if (currentUser?.role === Role.SUPERVISOR && user.collegeId !== currentUser.collegeId) return false; // Supervisors see only their college
            if (filter === 'all') return true;
            return user.status === filter;
        });
    }, [users, filter, currentUser]);

    return (
        <div>
            <h1 className="text-2xl font-bold text-cyan-400 mb-4">إدارة المستخدمين</h1>
            <div className="flex flex-wrap gap-2 mb-4">
                <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded ${filter === 'all' ? 'bg-cyan-500' : 'bg-gray-700'}`}>الكل</button>
                {Object.values(UserStatus).map(status => (
                    <button key={status} onClick={() => setFilter(status)} className={`px-4 py-2 rounded ${filter === status ? 'bg-cyan-500' : 'bg-gray-700'}`}>{status}</button>
                ))}
            </div>
            <div className="bg-gray-800 rounded-lg overflow-x-auto">
                <table className="w-full text-right min-w-[700px]">
                    <thead className="bg-gray-700">
                        <tr>
                            <th className="p-3">الاسم الكامل</th>
                            <th className="p-3">رقم القيد</th>
                            <th className="p-3">الكلية</th>
                            <th className="p-3">الدور</th>
                            <th className="p-3">الحالة</th>
                            <th className="p-3">الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredUsers.map(user => (
                            <tr key={user.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                <td className="p-3">{user.fullName}</td>
                                <td className="p-3">{user.id}</td>
                                <td className="p-3">{colleges.find(c => c.id === user.collegeId)?.name || '-'}</td>
                                <td className="p-3">{user.role}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-1 rounded-full text-xs font-semibold text-white ${
                                        user.status === UserStatus.APPROVED ? 'bg-green-600' : user.status === UserStatus.PENDING ? 'bg-yellow-600' : 'bg-red-600'
                                    }`}>{user.status}</span>
                                </td>
                                <td className="p-3 space-x-2 space-x-reverse">
                                    {user.status === UserStatus.PENDING && (
                                        <>
                                            <button onClick={() => actions.updateUserStatus(user.id, UserStatus.APPROVED)} className="text-green-400 hover:text-green-300">قبول</button>
                                            <button onClick={() => actions.updateUserStatus(user.id, UserStatus.REJECTED)} className="text-red-400 hover:text-red-300">رفض</button>
                                        </>
                                    )}
                                     {user.status !== UserStatus.PENDING && (
                                         <button onClick={() => actions.switchToUser(user)} className="text-blue-400 hover:text-blue-300 flex items-center gap-1"><EyeIcon className="w-4 h-4" /> معاينة</button>
                                     )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

const NotificationsScreen: React.FC = () => {
    const { state, actions } = useAppContext();
    const { currentUser, notifications } = state;

    if (!currentUser) return null;

    const userNotifications = notifications
        .filter(n => n.target === 'all' || (typeof n.target === 'object' && n.target.collegeId === currentUser.collegeId))
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    const handleMarkAsRead = (id: string) => {
        actions.markNotificationAsRead(id, currentUser.id);
    };

    return (
        <div>
            <h1 className="text-2xl font-bold text-cyan-400 mb-4">الإشعارات</h1>
            <div className="space-y-4">
                {userNotifications.map(n => {
                    const isRead = n.readBy.includes(currentUser.id);
                    return (
                        <div key={n.id} className={`p-4 rounded-lg relative ${isRead ? 'bg-gray-800' : 'bg-cyan-900/50 border border-cyan-700'}`}>
                            {!isRead && <span className="absolute top-2 right-2 w-3 h-3 bg-cyan-400 rounded-full"></span>}
                            <p className="text-gray-300">{n.message}</p>
                            <small className="text-gray-500 mt-2 block">{n.timestamp.toLocaleString('ar')}</small>
                            {!isRead && <button onClick={() => handleMarkAsRead(n.id)} className="text-cyan-400 text-sm mt-2">وضع علامة كمقروء</button>}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const AnnouncementScreen: React.FC = () => {
    const { state, actions } = useAppContext();
    const [message, setMessage] = useState('');
    const [target, setTarget] = useState<'all' | string>('all');
    const [sent, setSent] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!message.trim()) return;
        const targetPayload = target === 'all' ? { target: 'all' as 'all' } : { target: { collegeId: target } };
        await actions.addNotification({ message, ...targetPayload });
        setMessage('');
        setSent(true);
        setTimeout(() => setSent(false), 3000);
    };

    return (
        <div>
            <h1 className="text-2xl font-bold text-cyan-400 mb-4">إرسال إشعار</h1>
            <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-lg space-y-4 max-w-2xl">
                <div>
                    <label htmlFor="message" className="block mb-2 text-gray-300">نص الإشعار</label>
                    <textarea id="message" value={message} onChange={e => setMessage(e.target.value)} rows={5} required
                        className="w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 p-2"></textarea>
                </div>
                <div>
                    <label htmlFor="target" className="block mb-2 text-gray-300">إرسال إلى</label>
                    <select id="target" value={target} onChange={e => setTarget(e.target.value)}
                        className="w-full bg-gray-700 text-white rounded-md border-gray-600 focus:border-cyan-500 focus:ring-cyan-500 p-2">
                        <option value="all">جميع المستخدمين</option>
                        {state.colleges.map(c => <option key={c.id} value={c.id}>{`كلية ${c.name}`}</option>)}
                    </select>
                </div>
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-md transition-colors disabled:bg-gray-500" disabled={state.isLoading}>
                    {state.isLoading ? 'جاري الإرسال...' : 'إرسال الإشعار'}
                </button>
                {sent && <p className="text-green-400">تم إرسال الإشعار بنجاح!</p>}
            </form>
        </div>
    );
};


// --- Main Dashboard Component ---

const Dashboard: React.FC = () => {
    const { state, actions } = useAppContext();
    const [activeView, setActiveView] = useState('home');
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const [viewingFileUrl, setViewingFileUrl] = useState<string | null>(null);
    const { currentUser, originalUser, showInstallButton } = state;

    if (!currentUser) return null;

    const isAdmin = [Role.ADMIN, Role.PRIMARY_ADMIN, Role.SUPERVISOR].includes(currentUser.role);
    const isAssistant = currentUser.role === Role.ASSISTANT;

    const renderView = () => {
        switch (activeView) {
            case 'home':
                return <HomePage />;
            case 'content':
                if (currentUser.role === Role.STUDENT) return <StudentDashboard setViewingFileUrl={setViewingFileUrl} />;
                return <ContentManagementScreen setViewingFileUrl={setViewingFileUrl} />;
            case 'users':
                return isAdmin ? <UserManagement /> : <p>ليس لديك صلاحية الوصول لهذه الصفحة.</p>;
            case 'notifications':
                return <NotificationsScreen />;
            case 'announce':
                 return isAdmin ? <AnnouncementScreen /> : <p>ليس لديك صلاحية الوصول لهذه الصفحة.</p>;
            default:
                return <HomePage />;
        }
    };
    
    return (
        <div className="flex h-screen bg-gray-900 text-white" dir="rtl">
            {viewingFileUrl && <FileViewerModal url={viewingFileUrl} onClose={() => setViewingFileUrl(null)} />}
            <Sidebar 
                user={currentUser} 
                setActiveView={setActiveView} 
                activeView={activeView}
                isSidebarOpen={isSidebarOpen}
                setSidebarOpen={setSidebarOpen}
            />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header 
                    user={currentUser} 
                    onLogout={actions.logout} 
                    onSwitchBack={actions.switchBackToAdmin}
                    originalUser={originalUser}
                    onToggleSidebar={() => setSidebarOpen(!isSidebarOpen)}
                    showInstallButton={showInstallButton}
                    onInstall={actions.triggerInstallPrompt}
                />
                {originalUser && (
                    <div className="bg-yellow-600 text-white p-2 text-center font-semibold text-sm">
                        أنت الآن في وضع المعاينة كـ "{currentUser.fullName}". 
                        <button onClick={actions.switchBackToAdmin} className="underline font-bold mr-4 hover:text-yellow-200">
                            العودة إلى حساب المدير
                        </button>
                    </div>
                )}
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-800/50 p-4 md:p-6 lg:p-8">
                    {renderView()}
                </main>
            </div>
        </div>
    );
};

// --- Layout Components ---

interface SidebarProps {
    user: User;
    activeView: string;
    setActiveView: (view: string) => void;
    isSidebarOpen: boolean;
    setSidebarOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, activeView, setActiveView, isSidebarOpen, setSidebarOpen }) => {
    const { actions } = useAppContext();
    
    const navItems = [
        { id: 'home', label: 'الرئيسية', icon: <HomeIcon />, roles: Object.values(Role) },
        { id: 'content', label: 'المحتوى الدراسي', icon: <BookIcon />, roles: Object.values(Role) },
        { id: 'users', label: 'إدارة المستخدمين', icon: <UsersIcon />, roles: [Role.SUPERVISOR, Role.ADMIN, Role.PRIMARY_ADMIN] },
        { id: 'notifications', label: 'الإشعارات', icon: <BellIcon />, roles: Object.values(Role) },
        { id: 'announce', label: 'إرسال إشعار', icon: <MegaphoneIcon />, roles: [Role.SUPERVISOR, Role.ADMIN, Role.PRIMARY_ADMIN] },
    ];
    
    const visibleNavItems = navItems.filter(item => item.roles.includes(user.role));

    const handleItemClick = (viewId: string) => {
        setActiveView(viewId);
        setSidebarOpen(false);
    };

    return (
        <>
            <div className={`fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden ${isSidebarOpen ? 'block' : 'hidden'}`} onClick={() => setSidebarOpen(false)}></div>
            <aside className={`fixed md:relative flex-shrink-0 w-64 bg-gray-800 border-l border-gray-700 h-full flex flex-col z-40 transform ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-in-out`}>
                 <div className="h-16 flex items-center justify-between px-4 border-b border-gray-700">
                    <h2 className="text-2xl font-bold text-cyan-400">المنصة</h2>
                    <button className="md:hidden text-gray-400" onClick={() => setSidebarOpen(false)}><CloseIcon /></button>
                </div>
                <nav className="flex-1 p-4 space-y-2">
                    {visibleNavItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => handleItemClick(item.id)}
                            className={`w-full flex items-center p-3 rounded-lg transition-colors text-lg ${
                                activeView === item.id 
                                ? 'bg-cyan-500 text-white' 
                                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                            }`}
                        >
                            {React.cloneElement(item.icon, { className: 'w-6 h-6'})}
                            <span className="mr-3">{item.label}</span>
                        </button>
                    ))}
                </nav>
            </aside>
        </>
    );
};

interface HeaderProps {
    user: User;
    originalUser: User | null;
    onLogout: () => void;
    onSwitchBack: () => void;
    onToggleSidebar: () => void;
    showInstallButton: boolean;
    onInstall: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout, onToggleSidebar, showInstallButton, onInstall }) => {
    return (
        <header className="h-16 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-6 flex-shrink-0">
            <div className="flex items-center">
                 <button onClick={onToggleSidebar} className="text-gray-400 focus:outline-none md:hidden ml-4">
                    <MenuIcon />
                </button>
                <h1 className="text-xl font-semibold hidden md:block">لوحة التحكم</h1>
            </div>
            <div className="flex items-center gap-4">
                {showInstallButton && (
                    <button onClick={onInstall} className="flex items-center space-x-2 space-x-reverse p-2 rounded-md bg-cyan-600 hover:bg-cyan-700 transition-colors text-white" title="تثبيت التطبيق">
                        <DownloadIcon />
                        <span className="hidden sm:inline font-semibold">تثبيت التطبيق</span>
                    </button>
                )}
                <span className="text-gray-300 hidden sm:block">{user.fullName} ({user.role})</span>
                <button onClick={onLogout} className="flex items-center space-x-2 space-x-reverse p-2 rounded-md hover:bg-gray-700 transition-colors text-red-400" title="تسجيل الخروج">
                    <LogoutIcon />
                    <span className="hidden sm:inline">تسجيل الخروج</span>
                </button>
            </div>
        </header>
    );
};

export default Dashboard;