// A custom interface for the PWA install prompt event
export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: Array<string>;
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

export enum Role {
  STUDENT = 'طالب',
  ASSISTANT = 'مساعد',
  SUPERVISOR = 'مشرف',
  ADMIN = 'مدير',
  PRIMARY_ADMIN = 'مدير أساسي',
}

export enum UserStatus {
  PENDING = 'قيد الانتظار',
  APPROVED = 'معتمد',
  REJECTED = 'مرفوض',
  BANNED = 'محظور',
}

export enum ContentType {
    CURRICULUM = 'المنهج',
    LECTURES = 'المحاضرات',
    SUMMARIES = 'الملخصات',
    EXAMS = 'نماذج اختبارات',
}

export interface User {
  id: string; // University ID
  fullName: string;
  password: string;
  collegeId: string;
  specializationId?: string;
  levelId: string;
  phone: string;
  role: Role;
  status: UserStatus;
  assignedSubjectId?: string; // For assistants
}

export interface ContentFile {
    id: string;
    name: string;
    type: 'PDF' | 'VIDEO' | 'IMAGE' | 'LINK';
    url: string;
}

export interface Subject {
    id: string;
    name: string;
    content: {
        [ContentType.CURRICULUM]: ContentFile[];
        [ContentType.LECTURES]: ContentFile[];
        [ContentType.SUMMARIES]: ContentFile[];
        [ContentType.EXAMS]: ContentFile[];
    };
}

export interface Level {
    id: string;
    name: string;
    subjects: Subject[];
}

export interface Specialization {
    id: string;
    name: string;
    levels: Level[];
}

export interface College {
    id: string;
    name: string;
    specializations: Specialization[];
    levels: Level[]; // For colleges without specializations
}

export interface Notification {
    id: string;
    message: string;
    timestamp: Date;
    target: 'all' | { collegeId: string };
    readBy: string[];
}

export interface AppState {
  currentUser: User | null;
  originalUser: User | null; // For admin previewing as student
  colleges: College[];
  users: User[];
  notifications: Notification[];
  downloads: Record<string, number>; // fileId: progress
  isLoading: boolean;
  isInitialized: boolean;
  installPromptEvent: BeforeInstallPromptEvent | null;
  showInstallButton: boolean;
}